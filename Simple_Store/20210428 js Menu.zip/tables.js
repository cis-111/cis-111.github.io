// Javascript for Tables: Store Menu

"use strict;"
// window.alert("Javascript Connected");
// place table data array here
var tableDataArray = [
	{item: "gnarlyFries", price: 3.33},
	{item: "funkyFudge", price: 2.22},
	{item: "superSoda", price: 1.11},
	{item: "sodaStraw", price: 0.01},
	{item: "biggaBurger", price: 6.66},
	{item: "piezoPizza", price: 7.77},
	{item: "juicyJambalaya", price: 5.55},
	{item: "numerousNapkins", price: 0.01},
	{item: "gigaGratuity", price: 42},
];
// console.log("tableDataArray length is: " + tableDataArray.length);
// console.log("[3] item is: " + tableDataArray[3]);
// console.log("[7] item is: " + tableDataArray[7].item);
// console.log("[8] price is: " + tableDataArray[8].price);


// name variable to hold HTML code to build table.
var tableHTML = "<table>\n" + 
		"<caption>Yummy Menu</caption>\n" + 
		"<tr>\n" + 
		"<th>item</th>\n" + 
		"<th>price</th>\n" + 
		"</tr>\n";
// console.log(tableHTML);
// add row for each product
for (var i = 0; i < tableDataArray.length; i++) {
	// add table row for each tableDataArray[i]
	tableHTML += "<tr>\n<td>" + tableDataArray[i].item + "</td>\n";
	tableHTML += "<td>" + tableDataArray[i].price + "</td>\n</tr>\n"
}

// close table tag
// tableHTML = tableHTML + "</table>";
tableHTML += "</table>";
// console.log(tableHTML);
// didplay tableHTML in div.menu
document.getElementById("menu").innerHTML = tableHTML;



